import { getRefreshToken, setTokens } from "./storage.js"

function endpoint(apiUrl, path) {
  return `${apiUrl.replace(/\/$/, "")}${path}`
}

/**
 * Exchange the stored refresh token for a fresh session via the backend.
 * Reads + writes storage (not args) so it always rotates the LATEST token —
 * Supabase invalidates a refresh token once used, so a stale copy would fail.
 * Returns the new access token, or null when refresh isn't possible.
 */
async function refreshSession(apiUrl) {
  const refreshToken = await getRefreshToken()
  if (!refreshToken) return null
  const response = await fetch(endpoint(apiUrl, "/auth/refresh"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: refreshToken }),
  })
  if (!response.ok) return null
  const data = await response.json().catch(() => null)
  if (!data?.access_token) return null
  await setTokens({ token: data.access_token, refreshToken: data.refresh_token })
  return data.access_token
}

async function request(apiUrl, token, path, body, _retried = false, method = "POST") {
  if (!token) {
    const err = new Error("Connect Myro before saving jobs.")
    err.code = "auth_required"
    throw err
  }
  const init = {
    method,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  }
  if (method !== "GET" && method !== "HEAD") init.body = JSON.stringify(body)
  const response = await fetch(endpoint(apiUrl, path), init)
  // Access token expired (1h Supabase TTL) — refresh once and retry so the user
  // never has to reconnect mid-session.
  if (response.status === 401 && !_retried) {
    const fresh = await refreshSession(apiUrl)
    if (fresh) return request(apiUrl, fresh, path, body, true, method)
    // No working refresh token (stale/expired session) — signal the popup to
    // drop the dead token and surface "Connect with Myro" instead of trapping
    // the user on a retry loop.
    const err = new Error("Your Myro session expired. Reconnect to continue.")
    err.code = "auth_required"
    throw err
  }
  if (!response.ok) {
    const errorBody = await response.json().catch(() => ({}))
    throw new Error(errorBody.detail || `Myro API returned HTTP ${response.status}`)
  }
  return response.json()
}

function toPreviewPayload(draft) {
  return {
    source_url: draft.sourceUrl,
    source_platform: draft.sourcePlatform || "generic",
    role_name: draft.roleName || "",
    company_name: draft.companyName || null,
    location: draft.location || null,
    job_description: draft.jobDescription || "",
    page_title: draft.pageTitle || null,
    capture_method: draft.captureMethod || "visible_page",
    needs_backstop: draft.needsBackstop ?? false,
    json_ld: draft.jsonLd || null,
  }
}

export async function previewImport(apiUrl, token, draft) {
  return request(apiUrl, token, "/jobs/import/preview", toPreviewPayload(draft))
}

// Reach Intelligence (ADR-0018 Path 2): the backend reads the saved job by id,
// derives which leader roles to search for, and returns search URLs the user
// opens in their OWN browser. Myro never fetches the results — free, no coins.
export async function reachSearch(apiUrl, token, jobId) {
  return request(apiUrl, token, `/jobs/${encodeURIComponent(jobId)}/reach/search`, null, false, "GET")
}

// Page Entry: "which of my jobs is this page?" — the popup's first read. The
// server matches the URL against the user's own Collection and stages it with
// the same resolver as the Collections surface. `entry` is null for a new page.
export async function pageEntry(apiUrl, token, url) {
  return request(apiUrl, token, "/jobs/collections/page", { url })
}

// "I applied" — the user's own answer, the same write as web's "Did you apply?"
// Yes: status applied, any open Apply-click question answered, the CV of record
// frozen, and the door recorded (`applied` core-loop step) server-side.
export async function markApplied(apiUrl, token, jobId) {
  return request(apiUrl, token, `/jobs/applications/${encodeURIComponent(jobId)}`, { status: "applied", surface: "extension" }, false, "PUT")
}

export async function getFiling(apiUrl, token, jobId) {
  return request(apiUrl, token, `/jobs/${encodeURIComponent(jobId)}/filing`, null, false, "GET")
}

export async function postFilingAnswers(apiUrl, token, jobId, questions) {
  return request(apiUrl, token, `/jobs/${encodeURIComponent(jobId)}/filing/answers`, { questions })
}

export async function postFilingHold(apiUrl, token, jobId, reason) {
  return request(apiUrl, token, `/jobs/${encodeURIComponent(jobId)}/filing/hold`, { reason })
}

export async function postFilingReceipt(apiUrl, token, jobId, receiptUrl, receiptText) {
  return request(apiUrl, token, `/jobs/${encodeURIComponent(jobId)}/filing/receipt`, {
    receipt_url: receiptUrl,
    receipt_text: receiptText,
  })
}

export async function getFilingResume(apiUrl, token, jobId, _retried = false) {
  if (!token) {
    const err = new Error("Connect Myro before saving jobs.")
    err.code = "auth_required"
    throw err
  }
  const response = await fetch(endpoint(apiUrl, `/jobs/${encodeURIComponent(jobId)}/filing/resume`), {
    headers: { Authorization: `Bearer ${token}` },
  })
  if (response.status === 401 && !_retried) {
    const fresh = await refreshSession(apiUrl)
    if (fresh) return getFilingResume(apiUrl, fresh, jobId, true)
    const err = new Error("Your Myro session expired. Reconnect to continue.")
    err.code = "auth_required"
    throw err
  }
  if (response.status === 404) return null
  if (!response.ok) {
    const errorBody = await response.json().catch(() => ({}))
    throw new Error(errorBody.detail || `Myro API returned HTTP ${response.status}`)
  }
  const bytes = new Uint8Array(await response.arrayBuffer())
  let binary = ""
  const chunk = 0x8000
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk))
  }
  const header = response.headers.get("Content-Disposition") || ""
  const named = /filename="([^"]+)"/.exec(header)
  return { filename: named?.[1] || "cv.pdf", base64: btoa(binary) }
}

export async function saveImport(apiUrl, token, state) {
  return request(apiUrl, token, "/jobs/import", {
    source_url: state.sourceUrl,
    source_platform: state.sourcePlatform || "generic",
    role_name: state.roleName,
    company_name: state.companyName || null,
    location: state.location || null,
    job_description: state.jobDescription,
    primary_skills: state.primarySkills,
    secondary_skills: state.secondarySkills,
    emerging_skills: state.emergingSkills.map((label) => ({
      label,
      skill_type: "secondary",
      source: "user_added",
    })),
    capture_method: state.captureMethod || "visible_page",
  })
}
